import os

from dotenv import load_dotenv
from google import genai

load_dotenv()

_PROMPT_TEMPLATE = """
Analyze the following CV. Detect whether it is written in English or Arabic, \
then provide 3 specific, actionable improvement suggestions IN THE SAME LANGUAGE as the CV.
Return only the bullet points — no preamble.

{cv_text}
"""


def get_suggestions(cv_text: str) -> list[str]:
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise EnvironmentError("GOOGLE_API_KEY is not set.")

    client   = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=_PROMPT_TEMPLATE.format(cv_text=cv_text),
    )
    return [line.strip().strip("-* ") for line in response.text.splitlines() if line.strip()]
